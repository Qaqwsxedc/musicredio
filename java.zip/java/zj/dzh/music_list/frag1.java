package zj.dzh.music_list;

import androidx.fragment.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;



public class frag1 extends Fragment {
    //声明view
    private View view;
    //定义歌曲名称的数组
    public String[] name={"邓紫棋——光年之外","蔡健雅——红色高跟鞋","Taylor Swift——Love Story",
            "朴树——平凡之路","田馥甄——小幸运","周杰伦——七里香","林俊杰——江南"};
    //定义歌曲图片的数组
    public static int[] icons={R.drawable.music0,R.drawable.music1,R.drawable.music2,
            R.drawable.music3,R.drawable.music4,R.drawable.music5,R.drawable.music6};
    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        view=inflater.inflate(R.layout.music_list,null);
        //定义列表，并且绑定控件
        ListView listView=view.findViewById(R.id.lv);
        //声明适配器
        MyBaseAdapter adapter=new MyBaseAdapter();
        //给列表设置适配器
        listView.setAdapter(adapter);
        //设置监听器
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //创建Intent对象，启动音乐播放界面
                Intent intent=new Intent(frag1.this.getContext(), MusicActivity.class);
                //将数据存入Intent对象，利用键值对
                intent.putExtra("name",name[position]);
                intent.putExtra("position",String.valueOf(position));
                //开启意图
                startActivity(intent);
            }
        });
        return view;
    }
    class MyBaseAdapter extends BaseAdapter{
        @Override
        public int getCount(){return  name.length;}
        @Override
        public Object getItem(int i){return name[i];}
        @Override
        public long getItemId(int i){return i;}

        @Override
        public View getView(int i ,View convertView, ViewGroup parent) {
            View view=View.inflate(frag1.this.getContext(),R.layout.item_layout,null);
            TextView tv_name=view.findViewById(R.id.item_name);
            ImageView iv=view.findViewById(R.id.iv);

            tv_name.setText(name[i]);
            iv.setImageResource(icons[i]);
            return view;
        }
    }


}

