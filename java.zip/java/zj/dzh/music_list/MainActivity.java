package zj.dzh.music_list;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;



public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    //声明变量
    private FrameLayout content;
    private TextView tv1,tv2;
    private FragmentManager fm;
    private FragmentTransaction ft;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //必须重写的onCreate方法
        super.onCreate(savedInstanceState);
        //设定对应的布局文件
        setContentView(R.layout.activity_main);
        //绑定控件
        content=(FrameLayout)findViewById(R.id.content);
        tv1=(TextView)findViewById(R.id.menu1);
        tv2=(TextView)findViewById(R.id.menu2);
        //设置监听器
        tv1.setOnClickListener(this);
        tv2.setOnClickListener(this);
        //若是继承FfragmentActivity，m=getFragmentManger();
        fm=getSupportFragmentManager();
        ft=fm.beginTransaction();
        //默认情况下显示frag1（音乐列表界面）
        ft.replace(R.id.content,new frag1());
        ft.commit();
    }
    @Override
    //点击事件
    public void onClick(View v){
        ft=fm.beginTransaction();
        //根据控件id来切换页面
        switch (v.getId()){
            case R.id.menu1:
                //如果是menu1，则音乐列表界面frag1替换content
                ft.replace(R.id.content,new frag1());
                break;
            case R.id.menu2:
                //如果是menu2，则专辑界面frag2替换content
                ft.replace(R.id.content,new frag2());
                break;
            default:
                break;
        }
        ft.commit();
    }
}
